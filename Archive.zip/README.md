


# README


This is project is about building a recommendation system using graph search methodologies. We will be comparing these different approaches and closely observe the limitations of each.





## DATA SET:

We will be using the move lens dataset.



## 
